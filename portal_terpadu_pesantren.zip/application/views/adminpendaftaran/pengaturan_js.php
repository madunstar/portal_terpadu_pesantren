<script>

   $('#datatable').DataTable({});
  </script>
  <script type="text/javascript">
    $(document).ready(function() {
      $('.summernote').summernote({
        height: 200,
        tabsize: 1
      });
    });
  </script>
