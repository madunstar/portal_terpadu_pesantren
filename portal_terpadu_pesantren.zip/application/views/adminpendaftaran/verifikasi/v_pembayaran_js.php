<script>
 $(document).ready(function(){
   $('#datatable').DataTable({});

});
</script>