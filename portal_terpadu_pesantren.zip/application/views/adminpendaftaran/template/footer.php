
</section>
</section>
<script src="<?php echo base_url('assets/js/jquery.min.js');?>"></script>
  <!-- Bootstrap -->
  <script src="<?php echo base_url('assets/js/bootstrap.js');?>"></script>
  <!-- App -->
  <script src="<?php echo base_url('assets/js/app.js');?>"></script>
  <script src="<?php echo base_url('assets/js/slimscroll/jquery.slimscroll.min.js');?>"></script>
    <script src="<?php echo base_url('assets/js/charts/easypiechart/jquery.easy-pie-chart.js');?>"></script>
  <script src="<?php echo base_url('assets/js/charts/sparkline/jquery.sparkline.min.js');?>"></script>
  <script src="<?php echo base_url('assets/js/charts/flot/jquery.flot.min.js');?>"></script>
  <script src="<?php echo base_url('assets/js/charts/flot/jquery.flot.tooltip.min.js');?>"></script>
  <script src="<?php echo base_url('assets/js/charts/flot/jquery.flot.spline.js');?>"></script>
  <script src="<?php echo base_url('assets/js/charts/flot/jquery.flot.pie.min.js');?>"></script>
  <script src="<?php echo base_url('assets/js/charts/flot/jquery.flot.resize.js');?>"></script>
  <script src="<?php echo base_url('assets/js/charts/flot/jquery.flot.grow.js');?>"></script>
  <script src="<?php echo base_url('assets/js/charts/flot/demo.js');?>"></script>
  <script src="<?php echo base_url('assets/js/confirm/jquery-confirm.min.js');?>"></script>
  <script src="<?php echo base_url('assets/js/calendar/bootstrap_calendar.js');?>"></script>
  <script src="<?php echo base_url('assets/js/calendar/demo.js');?>"></script>
  <script src="<?php echo base_url('assets/js/parsley/parsley.min.js') ?>"></script>
  <script src="<?php echo base_url('assets/js/parsley/parsley.extend.js') ?>"></script>
  <script src="<?php echo base_url('assets/js/datatable/jquery.dataTables.js');?>"></script>
  <script src="<?php echo base_url('assets/js/datatable/dataTables.bootstrap.js');?>"></script>
  <script src="<?php echo base_url('assets/js/app.plugin.js');?>"></script>
  <script src="<?php echo base_url('assets/js/datepicker/bootstrap-datepicker.js');?>"></script>
  <script src="<?php echo base_url('assets/js/file-input/bootstrap-filestyle.min.js');?>"></script>
  <script src="<?php echo base_url('assets/js/wysiwyg/jquery.hotkeys.js');?>"></script>
  <script src="<?php echo base_url('assets/js/wysiwyg/bootstrap-wysiwyg.js');?>"></script>
  <script src="<?php echo base_url('assets/js/wysiwyg/demo.js');?>"></script>
  <script src="<?php echo base_url('assets/js/summernote/summernote.js');?>"></script>

  <script src="<?php echo base_url('assets/js/markdown/epiceditor.min.js');?>"></script>
  <script src="<?php echo base_url('assets/js/markdown/demo.js');?>"></script>
