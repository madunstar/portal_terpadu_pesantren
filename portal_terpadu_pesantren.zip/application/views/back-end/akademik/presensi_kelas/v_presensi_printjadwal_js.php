<script>

   $('#datatable').DataTable({});


</script>
